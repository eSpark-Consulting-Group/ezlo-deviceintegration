print( "TEST_PLUGIN: Startup" )

require "core"
core.send_ui_broadcast( { msg = "Startup script execute" } )
