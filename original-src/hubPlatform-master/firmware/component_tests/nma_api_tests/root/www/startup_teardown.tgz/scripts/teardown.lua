print( "TEST_PLUGIN: Teardown" )

require "core"
core.send_ui_broadcast( { msg = "Teardown script execute" } )
