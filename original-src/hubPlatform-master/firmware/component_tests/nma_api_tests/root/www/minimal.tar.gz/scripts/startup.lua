local _logger = require("logging")

_logger.info("Minimal plugin starting...")

_logger.info("Minimal plugin started")
