local _core = require("core")
local _logger = require("logging")

local _M = {}

function _M.create (server_address, username, password)
    if not server_address or server_address == "" then
        _logger.error("Server address is empty")
        _core.send_ui_broadcast({
            status = "error",
            message = "Server address is empty."
        })
        return
    end

    username = username or ''
		password = password or ''

    local device_id = _core.add_device({
        type = "device",
        device_type_id = "mqtt_client",
        category = "generic_io",
        subcategory = "generic_io",
        battery_powered = false,
        gateway_id = _core.get_gateway().id,
        name = "MQTT Client"
    })

    if not device_id then
        _logger.error("Failed to create device")
        _core.send_ui_broadcast({
            status = "error",
            message = "Device is not added. Cannot continue."
        })
        return
    end

    _logger.info("Created device with ID: " .. device_id)
    _core.send_ui_broadcast({
        status = "success",
        message = "Device added successfully."
    })

		loadfile("HUB:luiz.mqtt/scripts/settings/set_address") { device_id = device_id, value = server_address }
    --loadfile("HUB:luiz.mqtt/scripts/settings/set_username") { device_id = device_id, value = username }
    --loadfile("HUB:luiz.mqtt/scripts/settings/set_password") { device_id = device_id, value = password }

    return device_id
end

function _M.delete(device_id)
	if not device_id then
			_logger.error("Missing device ID, can't delete device")
			return
	end

	_logger.info("Delete device: " .. device_id)
	_core.remove_device(device_id)
end

return _M

