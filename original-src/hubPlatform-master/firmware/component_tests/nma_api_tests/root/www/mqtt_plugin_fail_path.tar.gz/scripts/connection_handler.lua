local _logger = require('logging')
local _network = require('network')
local _core = require('core')
local _storage = require('storage')

local params = ...

local activity_type = params.data.event.io_activity_type
local handle = params.data.event.handle
-- TODO: Remove this after adding address passing functionality.

local _mqtt_client = loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_client"){ handle = handle }
local _mqtt_device = loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_device")()


local function add_to_storage(table_name, key, value)
	local table = _storage.get_table(table_name) or {}

	if table[key] then
		_logger.debug('Key ('..key..') on table "'..table_name..'" already exists. Overwriting it...')
	end

	table[key] = value

	_storage.set_table(table_name, table)
end

local function remove_from_storage(table_name, key)
	local table = _storage.get_table(table_name)

	if not table then
		return
	end

	if table[key] == nil then
		_logger.error('Key ('..key..') trying to be deleted from table "'..table_name..'" does not exist.')
		return
	end

	table[key] = nil

	_storage.set_table(table_name, table)
end


if activity_type == "CONNECTED" then
	local connecting_params = _storage.get_table('connecting_params')

	local address = connecting_params.address
	local username = connecting_params.username
	local password = connecting_params.password
	local topic = connecting_params.topic

	local device_id = _mqtt_device.create(address, username, password)

	add_to_storage('device_id_from_handle', handle, device_id)
	add_to_storage('handle_from_device_id', device_id, handle)

	local connack = _mqtt_client.connect({
		address = address,
		username = username,
		password = password,
	})
	if connack.return_code ~= 0 then
		_logger.error('Connection refused by server (return code '..connack.return_code..')')
		_core.send_ui_broadcast({
			status = "error",
			message = "MQTT Connection refused by server."
		})
		return
	end

	if topic ~= nil and topic ~= '' then
		_mqtt_client.subscribe{
			topics = topic,
			packet_id = 2,
		}
	end

	_network.set_handler(handle, "HUB:luiz.mqtt/scripts/network_input_handler")

	_mqtt_client.subscribe({
		topics = 'ezlo_mqtt/set/item/#',
		packet_id = 1,
		qos = 0,
	})

	local items = {}

	items.mqtt_packet_send = _core.add_item({
		device_id = device_id,
		name = 'mqtt_packet_send',
		has_getter = false,
		has_setter = true,
		show = true,
		value_type = 'dictionary.string',
		value = {},
	})

	items.mqtt_message = _core.add_item({
		device_id = device_id,
		name = 'mqtt_message',
		has_getter = true,
		has_setter = false,
		show = true,
		value_type = 'string',
		value = "",
	})

	items.mqtt_topic = _core.add_item({
		device_id = device_id,
		name = 'mqtt_topic',
		has_getter = true,
		has_setter = false,
		show = true,
		value_type = 'string',
		value = "",
	})

	_storage.set_table('items', items)
	_logger.info('Mqtt client with handle '..tostring(handle)..' successfully connected.')

	_core.send_ui_broadcast({
		status = "success",
		message = "Successfully connected to MQTT server."
	})

elseif activity_type == "FAIL_TO_CONNECT" then
	_core.send_ui_broadcast({
		status = "error",
		message = "Connection failed."
	})
elseif activity_type == 'CONNECTION_CLOSED' then
	_core.send_ui_broadcast({
		status = "error",
		message = "MQTT Client disconnected."
	})

	local device_id = _storage.get_table('device_id_from_handle')[handle]

	_mqtt_device.delete(device_id)

	remove_from_storage('device_id_from_handle', handle)
	remove_from_storage('handle_from_device_id', device_id)
end

--_logger.debug(params)

