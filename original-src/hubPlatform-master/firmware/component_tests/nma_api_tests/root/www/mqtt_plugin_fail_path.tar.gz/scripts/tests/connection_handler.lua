local _logger = require('logging')
local _core = require('core')
local _network = require('network')

local params = ...

local activity_type = params.data.event.io_activity_type
local handle = params.data.event.handle
-- TODO: Remove this after adding address passing functionality.
local server_address = '127.0.0.1'


if activity_type == "CONNECTED" then
	_network.set_handler(handle, 'HUB:luiz.mqtt/scripts/tests/input_handler')

elseif activity_type == "FAIL_TO_CONNECT" then
	_core.send_ui_broadcast{
		status = "error",
		message = "Connection testing server failed."
	}
end
