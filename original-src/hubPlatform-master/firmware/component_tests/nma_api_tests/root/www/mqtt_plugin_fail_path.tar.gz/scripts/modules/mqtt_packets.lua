-- TODO: Implement suback.

-- TODO: Implement acknowledgement.
-- TODO: Implement packet identifiers use.
-- TODO: Implement persistent session.
-- TODO: Implement QOS 1 and 2.

local params = ...

local handle = params.handle

if not handle then
	error('Handle not specified')
end

local _M = {}

--------------------------------------
-- Generally useful funcions.

local function enumerate(iterator)
	return function (index)
		return (index or 0)+1, iterator()
	end
end
_M.enumerate = enumerate

local function print_binary(raw_binary)
	for c in raw_binary:gmatch'.' do
		io.write(string.byte(c)..' ')
	end
	print()
end
_M.print_binary = print_binary

local function get_binary_string(num, min_size)
	min_size = min_size or 1

	if num == true then
		num = 1
	elseif num == false then
		num = 0
	end

	local largest_power = 1
	while num >= largest_power do
		largest_power = largest_power * 2
	end
	largest_power = largest_power / 2

	local str = ''
	while largest_power >= 1 do
		if num >= largest_power then
			str = str..'1'
			num = num - largest_power
		else
			str = str..'0'
		end
		largest_power = largest_power / 2
	end

	while min_size > #str do
		str = '0'..str
	end

	return str
end
_M.get_binary_string = get_binary_string

local function num_to_bytes(num, min_size)
	min_size = min_size or 0
	local binary = get_binary_string(num, min_size*8)

	-- Completing zeros to form a byte.
	binary = string.rep("0", (8-(#binary%8))%8)..binary

	local bytes = {}
	for i=1,#binary,8 do
		bytes[#bytes+1] = string.char(tonumber(string.sub(binary, i, i+7), 2))
	end

	return table.concat(bytes)
end
_M.num_to_bytes = num_to_bytes

local function bytes_to_num(bytes)
	if #bytes > 8 then error("numbers can only be 8 bytes or less") end

	local num = 0
	
	for i=1,#bytes do
		num = num + (string.byte(bytes:sub(i,i)) << ((#bytes - i)*8))
	end

	return num
end
_M.bytes_to_num = bytes_to_num

local function from_variable_integer(bytes)
	local multiply = 1
	local value = 0

	for byte in bytes:gmatch'.' do
		byte = string.byte(byte)

		value = value + ((byte & 127) * multiply)
		multiply = multiply * 128
	end

	return value, nil
end
_M.from_variable_integer = from_variable_integer

local function to_variable_integer(num)
	local bytes = ''

	repeat
		local byte = num % 128

		num = num >> 7

		if num > 0 then
			byte = byte | 128
		end

		bytes = bytes..string.char(byte)
	until num == 0

	return bytes, nil
end
_M.to_variable_integer = to_variable_integer


--------------------------------------
-- Packets

local DEFAULT_PROTOCOL_LEVEL = 4
local DEFAULT_KEEP_ALIVE = 0

local MQTT_PACKET_TYPE = {
	[1] = 'connect',
	[2] = 'connack',
	[3] = 'publish',
	[4] = 'puback',
	[5] = 'pubrec',
	[6] = 'pubrel',
	[7] = 'pubcomp',
	[8] = 'subscribe',
	[9] = 'suback',
	[10] = 'unsubscribe',
	[11] = 'unsuback',
	[12] = 'pingreq',
	[13] = 'pingresp',
	[14] = 'disconnect',

	['connect'] = 1,
	['connack'] = 2,
	['publish'] = 3,
	['puback'] = 4,
	['pubrec'] = 5,
	['pubrel'] = 6,
	['pubcomp'] = 7,
	['subscribe'] = 8,
	['suback'] = 9,
	['unsubscribe'] = 10,
	['unsuback'] = 11,
	['pingreq'] = 12,
	['pingresp'] = 13,
	['disconnect'] = 14,
}

-- Returns the packet type according to its first byte.
local function identify_packet(packet)
	return MQTT_PACKET_TYPE[string.byte(packet:sub(1,1)) >> 4]
end
_M.identify_packet = identify_packet

_M.protocol = {}
_M.protocol[4] = {}
_M.protocol[5] = {}

_M.protocol[4].PacketConnect = {}
_M.protocol[4].PacketConnect.__index = _M.protocol[4].PacketConnect
_M.protocol[4].PacketConnect.new = function(self, args)
	local packet = {}

	-- Copying data.
	packet.flags = args.flags
	packet.protocol_level = args.protocol_level
	packet.keep_alive = args.keep_alive
	packet.will_topic = args.will_topic
	packet.will_message = args.will_message
	packet.username = args.username
	packet.password = args.password
	packet.client_id = args.client_id

	-- Setting defaults
	packet.flags = packet.flags or {}
	packet.client_id = packet.client_id or ''
	packet.protocol_level = packet.protocol_level or DEFAULT_PROTOCOL_LEVEL
	packet.keep_alive = packet.keep_alive or DEFAULT_KEEP_ALIVE
	if not packet.username or packet.username == '' then
		packet.username = nil
	end
	if not packet.password or packet.password == '' then
		packet.password = nil
	end

	-- Checking for bad data.
	if packet.flags.will and (not packet.will_topic or not packet.will_message) then
		error('will flag set without topic/message')
	end
	if #packet.client_id == 0 and packet.flags.clean_session == false then
		error('the cliend must have an id when \'Clean Session\' is true')
	end
	if packet.username then
		packet.flags.username = true
	end
	if packet.password then
		packet.flags.password = true
	end

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _', as some values may be `false`.
	if packet.flags.username == nil then
		packet.flags.username = false
	end
	if packet.flags.password == nil then
		packet.flags.password = false
	end
	if packet.flags.will_retain == nil then
		packet.flags.will_retain = false
	end
	if packet.flags.will_qos == nil then
		packet.flags.will_qos = 0
	end
	if packet.flags.will == nil then
		packet.flags.will = false
	end
	if packet.flags.clean_session == nil then
		packet.flags.clean_session = true
	end
	if packet.flags.reserved == nil then
		packet.flags.reserved = false
	end

  setmetatable(packet, self)
  return packet
end

-- WARNING: Unfinished.
_M.protocol[4].PacketConnect.from_binary = function(self, raw_bytes)
	local newprotocol[4].PacketConnect = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	-- Retrieving packet type.
	local packet_type = identify_packet(byte)
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'connect' then
		error('packet type not CONNECT')
	end

	newprotocol[4].PacketConnect.packet_type = packet_type
	
	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	newprotocol[4].PacketConnect.remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))

	-- Retrieving protocol name.
	local msb, lsb
	index, msb = bytes_iter(index)
	index, lsb = bytes_iter(index)

	local len = bytes_to_num(msb..lsb)

	local protocol = ''
	for _=1,4 do
		index, byte = bytes_iter(index)
		protocol = protocol..byte
	end

	if len ~= 4 or protocol ~= 'MQTT' then error('not an MQTT procotol packet') end

	-- Retrieving protocol level.
	local protocol_level
	index, protocol_level = bytes_iter(index)
	if protocol_level ~= 4 then error('protocol level if '..string.byte(protocol_level)..', but should be 4') end

	-- Retrieving connect flags.
	index, byte = bytes_iter(index)

	-- TODO: Finish this! (warning: this will only be useful for a server implementation)
	--local flags = {
	--  user_name = 
	--  password = 
	--  will_retain = 
	--  will_qos = 
	--  will = 
	--  clean_session = 
	--  reserved = 
	--}

  setmetatable(newprotocol[4].PacketConnect, self)
  return newprotocol[4].PacketConnect
end

_M.protocol[4].PacketConnect.to_binary = function(self)
	local payload = ''
	if self.flags.password then
		payload = num_to_bytes(#self.password, 2)..self.password..payload
	end
	if self.flags.username then
		payload = num_to_bytes(#self.username, 2)..self.username..payload
	end
	if self.flags.will then
		payload = num_to_bytes(#self.will_topic, 2)..self.will_topic..payload
		payload = num_to_bytes(#self.will_message, 2)..self.will_message..payload
	end
	payload = num_to_bytes(#self.client_id, 2)..self.client_id..payload

	local flags = get_binary_string(self.flags.username)
			..get_binary_string(self.flags.password)
			..get_binary_string(self.flags.will_retain)
			..get_binary_string(self.flags.will_qos, 2)
			..get_binary_string(self.flags.will)
			..get_binary_string(self.flags.clean_session)
			..'0'
	flags = string.char(tonumber(flags, 2))

	local variable_header = string.char(0, 4)..'MQTT'..string.char(self.protocol_level)..flags..num_to_bytes(self.keep_alive, 2)

	local fixed_header = string.char(MQTT_PACKET_TYPE['connect'] << 4)..to_variable_integer(#variable_header + #payload)

	local raw_packet = fixed_header..variable_header..payload

	return raw_packet
end

_M.protocol[4].PacketConnect.type = function(self)
	return 'connect'
end

_M.protocol[5].PacketConnect = {}
_M.protocol[5].PacketConnect.__index = _M.protocol[4].PacketConnect
_M.protocol[5].PacketConnect.new = function(self, args)
	local packet = {}

	-- Copying data.
	packet.flags = args.flags
	packet.protocol_level = args.protocol_level
	packet.keep_alive = args.keep_alive
	packet.will_topic = args.will_topic
	packet.will_message = args.will_message
	packet.username = args.username
	packet.password = args.password
	packet.client_id = args.client_id

	-- Setting defaults
	packet.flags = packet.flags or {}
	packet.client_id = packet.client_id or ''
	packet.protocol_level = packet.protocol_level or DEFAULT_PROTOCOL_LEVEL
	packet.keep_alive = packet.keep_alive or DEFAULT_KEEP_ALIVE
	if not packet.username or packet.username == '' then
		packet.username = nil
	end
	if not packet.password or packet.password == '' then
		packet.password = nil
	end

	-- Checking for bad data.
	if packet.flags.will and (not packet.will_topic or not packet.will_message) then
		error('will flag set without topic/message')
	end
	if #packet.client_id == 0 and packet.flags.clean_session == false then
		error('the cliend must have an id when \'Clean Session\' is true')
	end
	if packet.username then
		packet.flags.username = true
	end
	if packet.password then
		packet.flags.password = true
	end

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _', as some values may be `false`.
	if packet.flags.username == nil then
		packet.flags.username = false
	end
	if packet.flags.password == nil then
		packet.flags.password = false
	end
	if packet.flags.will_retain == nil then
		packet.flags.will_retain = false
	end
	if packet.flags.will_qos == nil then
		packet.flags.will_qos = 0
	end
	if packet.flags.will == nil then
		packet.flags.will = false
	end
	if packet.flags.clean_session == nil then
		packet.flags.clean_session = true
	end
	if packet.flags.reserved == nil then
		packet.flags.reserved = false
	end

  setmetatable(packet, self)
  return packet
end

-- WARNING: Unfinished.
_M.protocol[5].PacketConnect.from_binary = function(self, raw_bytes)
	local newPacketConnect = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	-- Retrieving packet type.
	local packet_type = identify_packet(byte)
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'connect' then
		error('packet type not CONNECT')
	end

	newPacketConnect.packet_type = packet_type
	
	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	newPacketConnect.remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))

	-- Retrieving protocol name.
	local msb, lsb
	index, msb = bytes_iter(index)
	index, lsb = bytes_iter(index)

	local len = bytes_to_num(msb..lsb)

	local protocol = ''
	for _=1,4 do
		index, byte = bytes_iter(index)
		protocol = protocol..byte
	end

	if len ~= 4 or protocol ~= 'MQTT' then error('not an MQTT procotol packet') end

	-- Retrieving protocol level.
	local protocol_level
	index, protocol_level = bytes_iter(index)
	if protocol_level ~= 5 then error('protocol level is '..string.byte(protocol_level)..', but should be 5') end

	-- Retrieving connect flags.
	index, byte = bytes_iter(index)

	-- TODO: Finish this! (warning: this will only be useful for a server implementation)
	--local flags = {
	--  user_name = 
	--  password = 
	--  will_retain = 
	--  will_qos = 
	--  will = 
	--  clean_session = 
	--  reserved = 
	--}

  setmetatable(newPacketConnect, self)
  return newPacketConnect
end

_M.protocol[5].PacketConnect.to_binary = function(self)
	local payload = ''
	if self.flags.password then
		payload = num_to_bytes(#self.password, 2)..self.password..payload
	end
	if self.flags.username then
		payload = num_to_bytes(#self.username, 2)..self.username..payload
	end
	if self.flags.will then
		payload = num_to_bytes(#self.will_topic, 2)..self.will_topic..payload
		payload = num_to_bytes(#self.will_message, 2)..self.will_message..payload
	end
	payload = num_to_bytes(#self.client_id, 2)..self.client_id..payload

	local flags = get_binary_string(self.flags.username)
			..get_binary_string(self.flags.password)
			..get_binary_string(self.flags.will_retain)
			..get_binary_string(self.flags.will_qos, 2)
			..get_binary_string(self.flags.will)
			..get_binary_string(self.flags.clean_session)
			..'0'
	flags = string.char(tonumber(flags, 2))

	-- FIXME: For now, we have no property support.
	local properties = ''

	local variable_header = string.char(0, 4)..'MQTT'
			..string.char(self.protocol_level)
			..flags
			..num_to_bytes(self.keep_alive, 2)
			..to_variable_integer(#properties)
			..properties

	local fixed_header = string.char(MQTT_PACKET_TYPE['connect'] << 4)..to_variable_integer(#variable_header + #payload)

	local raw_packet = fixed_header..variable_header..payload

	return raw_packet
end

_M.protocol[5].PacketConnect.type = function(self)
	return 'connect'
end


_M.protocol[4].PacketConnack = {}
_M.protocol[4].PacketConnack.__index = _M.protocol[4].PacketConnack
_M.protocol[4].PacketConnack.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'connack' then
		error('packet type not CONNACK')
	end

	packet.packet_type = packet_type
	
	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	local remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))
	if remaining_len ~= 2 then
		error('invalid packet length for CONNACK')
	end

	-- Retrieving flags.
	packet.flags = {}

	local flags
	index, flags= bytes_iter(index)
	flags = string.byte(flags)

	packet.flags.session_present = (flags & 1 ~= 0)

	local return_code
	index, return_code= bytes_iter(index)
	
	packet.return_code = string.byte(return_code)

  setmetatable(packet, self)
  return packet
end

-- WARNING: Unfinished.
_M.protocol[4].PacketConnack.to_binary = function(self)
	local packet = ''

	-- Adding packet identifier.
	packet = num_to_bytes(self.packet_identifier, 2)..packet

	-- Adding remaining length.
	packet = to_variable_integer(#packet)..packet

	-- Adding first byte.
	packet = string.char(MQTT_PACKET_TYPE[self.packet_type] << 4)..packet
end

_M.protocol[4].PacketConnack.type = function(self)
	return 'connack'
end

_M.protocol[5].PacketConnack = {}
_M.protocol[5].PacketConnack.__index = _M.protocol[5].PacketConnack
-- WARNING: Incomplete (nonetheless, usable).
_M.protocol[5].PacketConnack.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'connack' then
		error('packet type not CONNACK')
	end

	packet.packet_type = packet_type

	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	local remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))
	if remaining_len ~= 2 then
		error('invalid packet length for CONNACK')
	end

	-- Retrieving flags.
	packet.flags = {}

	local flags
	index, flags= bytes_iter(index)
	flags = string.byte(flags)

	packet.flags.session_present = (flags & 1 ~= 0)

	local return_code
	index, return_code= bytes_iter(index)
	
	packet.return_code = string.byte(return_code)

	-- Retrieving variable integer 'property length'.
	start_index = index + 1
	end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	local properties_length = from_variable_integer(raw_bytes:sub(start_index, end_index))

	-- TODO: Use properties.

  setmetatable(packet, self)
  return packet
end

-- WARNING: Unfinished.
_M.protocol[5].PacketConnack.to_binary = function(self)
	local packet = ''

	-- Adding packet identifier.
	packet = num_to_bytes(self.packet_identifier, 2)..packet

	-- Adding remaining length.
	packet = to_variable_integer(#packet)..packet

	-- Adding first byte.
	packet = string.char(MQTT_PACKET_TYPE[self.packet_type] << 4)..packet
end

_M.protocol[5].PacketConnack.type = function(self)
	return 'connack'
end

_M.protocol[4].PacketPublish = {}
_M.protocol[4].PacketPublish.__index = _M.protocol[4].PacketPublish
_M.protocol[4].PacketPublish.new = function(self, args)
	local packet = {}

	-- Copying data.
	packet.flags = args.flags
	packet.qos = args.qos
	packet.topic = args.topic
	packet.packet_id = args.packet_id
	packet.message = args.message

	-- Setting defaults
	packet.flags = packet.flags or {}
	packet.qos = packet.qos or 0

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _' idiom, as some values may be `false`.
	if packet.flags.dup == nil then
		packet.flags.dup = false
	end
	if packet.flags.retain == nil then
		packet.flags.retain = false
	end

	-- Checking for bad data.
	if packet.topic == nil or #packet.topic == 0 then
		error('publish packet must have a (non-empty) topic')
	end
	if packet.message == nil then
		error('publish packet must have a message')
	end
	if packet.qos < 0 or packet.qos > 2 then
		error('invalid QOS level '..packet.qos)
	end
	if packet.qos == 0 and packet.flags.dup then
		error('dup flag must be false for publish packets with QOS 0')
	end

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketPublish.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'publish' then
		error('packet type not PUBLISH')
	end

	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	local remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))

	-- Retrieving flags.
	packet.flags = {}
	packet.flags.retain = (string.byte(byte) & 1 == 1)
	packet.flags.dup = (string.byte(byte) & 8 == 8)
	packet.qos = (string.byte(byte) & 6) >> 1

	-- Retrieving topic.
	local msb, lsb
	index, msb = bytes_iter(index)
	index, lsb = bytes_iter(index)

	local len = bytes_to_num(msb..lsb)

	-- FIXME: This operation is *slooooow*, and probably O(n). Change it to simply split the byte string.
	local topic = ''
	for _=1,len do
		index, byte = bytes_iter(index)
		topic = topic..byte
	end
	packet.topic = topic

	-- FIXME: This operation is *slooooow*, and probably O(n). Change it to simply split the byte string.
	-- Retrieving message.
	local message = ''
	for _=index,#raw_bytes-1 do
		index, byte = bytes_iter(index)
		message = message..byte
	end
	packet.message = message

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketPublish.to_binary = function(self)
	local payload = self.message

	local variable_header = num_to_bytes(#self.topic, 2)..self.topic
	if self.qos > 0 then
		variable_header = variable_header..self.packet_id
	end

	local flags = get_binary_string(self.flags.dup)..get_binary_string(self.qos, 2)..get_binary_string(self.flags.retain)
	flags = tonumber(flags, 2)

	local fixed_header = string.char((MQTT_PACKET_TYPE['publish'] << 4) + flags)..to_variable_integer(#variable_header + #payload)

	local raw_packet = fixed_header..variable_header..payload

	return raw_packet
end

_M.protocol[4].PacketPublish.type = function(self)
	return 'publish'
end


_M.protocol[4].PacketSubscribe = {}
_M.protocol[4].PacketSubscribe.__index = _M.protocol[4].PacketSubscribe
_M.protocol[4].PacketSubscribe.new = function(self, args)
	local packet = {}

	-- Copying data.
	packet.qos = args.qos
	packet.topics = args.topics
	packet.packet_id = args.packet_id

	-- Setting defaults
	packet.qos = packet.qos or 0

	-- Checking for bad data.
	if not packet.topics then
		error('subscribe packet must have at least one topic')
	end
	-- TODO: We should be able to generate a new id automatically. Implement a mechanism to keep track of the ids being used, and a method to return the next available id.
	if not packet.packet_id then
		error('subscribe packet must have a packet identifier')
	end

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _' idiom, as some values may be `false`.
	if packet.qos == nil then
		packet.qos = 2
	end

	-- Reformatting.
	if type(packet.topics) == 'string' then
		packet.topics = {packet.topics}
	end
	if type(packet.qos) == 'number' then
		local qos = packet.qos
		packet.qos = {}
		for i=1,#packet.topics do
			packet.qos[i] = qos
		end
	end

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketSubscribe.from_binary = function(self, raw_bytes)
	error('SUBSCRIBE packet\'s "from_binary" not implemented')
end

_M.protocol[4].PacketSubscribe.to_binary = function(self)
	local payload = ''
	for i=1,#self.topics do
		payload = payload..num_to_bytes(#self.topics[i], 2)..self.topics[i]..string.char(self.qos[i])
	end

	local variable_header = num_to_bytes(self.packet_id, 2)

	local fixed_header = string.char((MQTT_PACKET_TYPE['subscribe'] << 4) + 2)..to_variable_integer(#variable_header + #payload)

	return fixed_header..variable_header..payload
end

_M.protocol[4].PacketSubscribe.type = function(self)
	return 'subscribe'
end


_M.protocol[4].PacketSuback = {}
_M.protocol[4].PacketSuback.__index = _M.protocol[4].PacketSuback
_M.protocol[4].PacketSuback.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'suback' then
		error('packet type not SUBACK')
	end

	packet.packet_type = packet_type
	
	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	local remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))

	-- Retrieving packet_identifier.
	local msb, lsb
	index, msb = bytes_iter(index)
	index, lsb = bytes_iter(index)

	packet.packet_identifier = bytes_to_num(msb..lsb)

	-- Retrieving message.
	packet.return_codes = {}
	for _=index,#raw_bytes-1 do
		index, byte = bytes_iter(index)
		table.insert(packet.return_codes, bytes_to_num(byte))
	end

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketSuback.to_binary = function(self)
	local packet = ''

	-- Adding return codes.
	local codes = {}
	for code in self.return_codes do
		table.insert(codes, num_to_bytes(code))
	end
	codes = table.concat(codes)

	packet = codes..packet

	-- Adding packet identifier.
	packet = num_to_bytes(self.packet_identifier, 2)..packet

	-- Adding remaining length.
	packet = to_variable_integer(#packet)..packet

	-- Adding first byte.
	packet = string.char(MQTT_PACKET_TYPE[self.packet_type] << 4)..packet
end

_M.protocol[4].PacketSuback.type = function(self)
	return 'suback'
end


_M.protocol[4].PacketDisconnect = {}
_M.protocol[4].PacketDisconnect.__index = _M.protocol[4].PacketDisconnect
_M.protocol[4].PacketDisconnect.new = function(self)
	local packet = {}

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketDisconnect.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'disconnect' then
		error('packet type not DISCONNECT')
	end

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketDisconnect.to_binary = function(self)
	local fixed_header = string.char((MQTT_PACKET_TYPE['disconnect'] << 4))..to_variable_integer(0)

	local raw_packet = fixed_header

	return raw_packet
end

_M.protocol[4].PacketDisconnect.type = function(self)
	return 'publish'
end


_M.protocol[4].PacketPingreq = {}
_M.protocol[4].PacketPingreq.__index = _M.protocol[4].PacketPingreq
_M.protocol[4].PacketPingreq.new = function(self)
	local packet = {}

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketPingreq.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'pingreq' then
		error('packet type not DISCONNECT')
	end

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketPingreq.to_binary = function(self)
	local fixed_header = string.char((MQTT_PACKET_TYPE['pingreq'] << 4))..to_variable_integer(0)

	local raw_packet = fixed_header

	return raw_packet
end

_M.protocol[4].PacketPingreq.type = function(self)
	return 'pingreq'
end


_M.protocol[4].PacketPingresp = {}
_M.protocol[4].PacketPingresp.__index = _M.protocol[4].PacketPingresp
_M.protocol[4].PacketPingresp.new = function(self)
	local packet = {}

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketPingresp.from_binary = function(self, raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'pingresp' then
		error('packet type not DISCONNECT')
	end

  setmetatable(packet, self)
  return packet
end

_M.protocol[4].PacketPingresp.to_binary = function(self)
	local fixed_header = string.char((MQTT_PACKET_TYPE['pingresp'] << 4))..to_variable_integer(0)

	local raw_packet = fixed_header

	return raw_packet
end

_M.protocol[4].PacketPingresp.type = function(self)
	return 'pingresp'
end

return _M
