local _network = require('network')
local _logger = require('logging')

-- TODO: Implement acknowledgement.
-- TODO: Implement packet identifiers use.
-- TODO: Implement persistent session.
-- TODO: Implement QOS 1 and 2.

local params = ...

local handle = params.handle

local _mqtt_packets = loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_packets"){ handle = handle }

--------------------------------------
-- Useful data.

local packets = {}
local MQTT_PACKET_CLASS = {}

local function set_protocol(protocol)
	packets = {
		PacketConnect = _mqtt_packets.protocol[protocol].PacketConnect,
		PacketConnack = _mqtt_packets.protocol[protocol].PacketConnack,
		PacketPublish = _mqtt_packets.protocol[protocol].PacketPublish,
		PacketPuback = _mqtt_packets.protocol[protocol].PacketPuback,
		PacketPubrec = _mqtt_packets.protocol[protocol].PacketPubrec,
		PacketPubrel = _mqtt_packets.protocol[protocol].PacketPubrel,
		PacketPubcomp = _mqtt_packets.protocol[protocol].PacketPubcomp,
		PacketSubscribe = _mqtt_packets.protocol[protocol].PacketSubscribe,
		PacketSuback = _mqtt_packets.protocol[protocol].PacketSuback,
		PacketUnsubscribe = _mqtt_packets.protocol[protocol].PacketUnsubscribe,
		PacketUnsuback = _mqtt_packets.protocol[protocol].PacketUnsuback,
		PacketPingreq = _mqtt_packets.protocol[protocol].PacketPingreq,
		PacketPingresp = _mqtt_packets.protocol[protocol].PacketPingresp,
		PacketDisconnect = _mqtt_packets.protocol[protocol].PacketDisconnect,
	}

	MQTT_PACKET_CLASS = {
		['connect'] = packets.PacketConnect,
		['connack'] = packets.PacketConnack,
		['publish'] = packets.PacketPublish,
		['puback'] = packets.PacketPuback,
		['pubrec'] = packets.PacketPubrec,
		['pubrel'] = packets.PacketPubrel,
		['pubcomp'] = packets.PacketPubcomp,
		['subscribe'] = packets.PacketSubscribe,
		['suback'] = packets.PacketSuback,
		['unsubscribe'] = packets.PacketUnsubscribe,
		['unsuback'] = packets.PacketUnsuback,
		['pingreq'] = packets.PacketPingreq,
		['pingresp'] = packets.PacketPingresp,
		['disconnect'] = packets.PacketDisconnect,
	}
end

local from_variable_integer = _mqtt_packets.from_variable_integer
local to_variable_integer = _mqtt_packets.to_variable_integer

local MQTT_PACKET_TYPE = {
	[1] = 'connect',
	[2] = 'connack',
	[3] = 'publish',
	[4] = 'puback',
	[5] = 'pubrec',
	[6] = 'pubrel',
	[7] = 'pubcomp',
	[8] = 'subscribe',
	[9] = 'suback',
	[10] = 'unsubscribe',
	[11] = 'unsuback',
	[12] = 'pingreq',
	[13] = 'pingresp',
	[14] = 'disconnect',

	['connect'] = 1,
	['connack'] = 2,
	['publish'] = 3,
	['puback'] = 4,
	['pubrec'] = 5,
	['pubrel'] = 6,
	['pubcomp'] = 7,
	['subscribe'] = 8,
	['suback'] = 9,
	['unsubscribe'] = 10,
	['unsuback'] = 11,
	['pingreq'] = 12,
	['pingresp'] = 13,
	['disconnect'] = 14,
}


-- Returns the packet type according to its first byte.
function identify_packet_binary(packet)
	return MQTT_PACKET_TYPE[string.byte(packet:sub(1,1)) >> 4]
end

--------------------------------------
-- MQTT functions.

local _M = {}

function _M.connect_with_protocol(protocol, args)
	set_protocol(protocol)
	local connect_packet = packets.PacketConnect:new(args)

	_network.send(handle, connect_packet:to_binary())

	local packet = _M.receive_packet()

	if packet:type() ~= 'connack' then
		error('message received upon connection to server is not connack')
	end

	return packet
end

function _M.connect(args)
	-- Try to connect with mqtt 5.0 (protocol 5).
	local packet = _M.connect_with_protocol(5, args)
	if packet.return_code == 0 then
		return packet
	end

	_logger.debug("RETURN CODE: "..tostring(packet.return_code))

	-- Try to connect with mqtt 3.1.1 (protocol 4).
	packet = _M.connect_with_protocol(4, args)

	_logger.debug("RETURN CODE: "..tostring(packet.return_code))

	return packet
end

function _M.publish(args)
	local publish_packet = PacketPublish:new(args)

	_network.send(handle, publish_packet:to_binary())

	-- TODO: Once you start implement the highier QOS systems, change this to receive the acknowledgement.
	--result, err = self:receive_packet_binary()
	--if not result then error(err) end
  --
	--local connack_binary = result
  --
	--if identify_packet_binary(connack_binary) ~= 'connack' then
	--  error('message received upon connection to server is not connack')
	--end

	--return PacketConnack:from_binary(connack_binary)
	return nil
end

function _M.subscribe(args)
	local subscribe_packet = PacketSubscribe:new(args)

	local raw = ''
	for c in subscribe_packet:to_binary():gmatch('.') do
		raw = raw..tostring(string.byte(c))..' '
	end

	_network.send(handle, subscribe_packet:to_binary())

	local packet = _M.receive_packet()
	if packet:type() ~= 'suback' then
		error('message received upon connection to server is not suback')
	end

	return packet
end

function _M._receive_variable_integer()
	local bytes = ''
	local result

	repeat
		if #bytes > 4 then
			error('malformed remaining length')
		end

		repeat
			result = _network.receive(handle, 1)
		until result ~= ''

		bytes = bytes..result
	until (string.byte(result) & 128) == 0

	return bytes, nil
end

function _M.receive_packet()
	local binary = _M.receive_packet_binary()
	local packet_type = identify_packet_binary(binary)
	local PacketClass = MQTT_PACKET_CLASS[packet_type]

	if not PacketClass then
		error('Invalid packet type '..packet_type)
	end

	return PacketClass:from_binary(binary)
end

function _M.receive_packet_binary()
	-- Receiving first byte.
	local first_byte
	repeat
		first_byte = _network.receive(handle, 1)
	until first_byte ~= ''

	if not identify_packet_binary(first_byte) then
		error("malformed MQTT packet received")
	end

	-- Receiving remaining length.
	local remaining_len = from_variable_integer(_M._receive_variable_integer())

	-- Receiving remaining of the packet.
	local remaining = ''
	repeat
		remaining = remaining.._network.receive(handle, (remaining_len - #remaining))
	until #remaining == remaining_len

	return first_byte..to_variable_integer(remaining_len)..remaining
end

return _M


