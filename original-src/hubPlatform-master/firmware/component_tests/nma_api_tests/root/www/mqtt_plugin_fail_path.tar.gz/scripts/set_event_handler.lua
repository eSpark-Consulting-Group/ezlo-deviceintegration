local _logger = require('logging')
local _core = require('core')
local _storage = require('storage')

local SET_PREFIX = 'ezlo_mqtt/set'

local params = ...

local activity_type = params.data.event.io_activity_type
local handle = params.data.event.handle
-- TODO: Remove this after adding address passing functionality.
local server_address = '127.0.0.1'

local mqtt_client = loadfile("HUB:luiz.mqtt/scripts/mqtt_client"){ handle = handle }

local packet = mqtt_client.receive_packet()
if packet.type() ~= ''


if activity_type == "CONNECTED" then
	_core.send_ui_broadcast({
		status = "success",
		message = "Successfully connected to MQTT server."
	})
	
	local connack = mqtt_client.connect()
	if connack.return_code ~= 0 then
		_logger.error('Connection refused by server (return code '..connack.return_code..')')
	_core.add_item({
		device_id = device_id,
		name = 'MQTT Topic',
		has_getter = true,
		has_setter = true,
		show = true,
		value_type = 'string',
		value = 'test/topic',
	})
		return
	end

	--mqtt_client.subscribe({
	--  topics = 'ezlo_mqtt/set/item/#',
	--  packet_id = 1,
	--  qos = 0,
	--})

	-- FIXME: For now, we ignore address and go to localhost, since the API doesn't support remote connection. Change it to use the actual server once it functions.
	-- FIXME: We are ignoring the username and password (both are nil).
	local device_id = mqtt_device.create('127.0.0.1', username, password)

	-- Adding 'handle' to list.
	local active_connections = _storage.get_table('active_connections')
	if active_connections[handle] then
		_logger.warning('Handle ('..handle..') being reused by MQTT client.')
	end
	active_connections[handle] = {
		device_id = device_id,
	}
	_storage.set_table('active_connections', active_connections)

elseif activity_type == "FAIL_TO_CONNECT" then
	_core.send_ui_broadcast({
		status = "error",
		message = "Failed to connect to the server."
	})
elseif activity_type == 'CONNECTION_CLOSED' then
	_core.send_ui_broadcast({
		status = "error",
		message = "MQTT Client disconnected"
	})

	local device_id

	-- Removing 'handle' from list.
	local active_connections = _storage.get_table('active_connections')
	if not active_connections[handle] then
		_logger.error('Handle ('..handle..') caught disconnecting, but was not previously registered.')
		return
	else
		device_id = active_connections[handle].device_id
		active_connections[handle] = nil
	end

	mqtt_device.delete(device_id)
	_storage.set_table('active_connections', active_connections)
end

--_logger.debug(params)

