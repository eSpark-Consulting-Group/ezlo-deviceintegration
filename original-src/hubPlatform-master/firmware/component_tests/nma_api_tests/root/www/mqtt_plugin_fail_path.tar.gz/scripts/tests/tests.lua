local _logger = require('logging')
local _network = require('network')

local server_address = '127.0.0.1'

_network.subscribe('HUB:luiz.mqtt/scripts/tests/connection_handler')
local handle = _network.connect{
	ip = server_address,
	port = '1883',
	connection_type = 'TCP',
}
_network.unsubscribe('HUB:luiz.mqtt/scripts/tests/connection_handler')

local function assert_equals(v0, v1)
	if v1 == v0 then
		return
	end

	_logger.error('Test failed: '..v0..' != '..v1)
end

local mqtt_packets = loadfile("HUB:luiz.mqtt/scripts/mqtt_packet"){
	handle = handle,
	username = 'ezlo_test_username',
	password = '123456789',
	client_id = 'ezlo_test_client_id',
}

local function test_packets()
	assert_equals(mqtt_packets.get_binary_string(5), '101')
	assert_equals(mqtt_packets.get_binary_string(11, 6), '001011')
	assert_equals(mqtt_packets.num_to_bytes(1633837924), 'abcd')
	assert_equals(mqtt_packets.bytes_to_num(mqtt_packets.num_to_bytes(12345)), 12345)
	assert_equals(mqtt_packets.from_variable_integer(mqtt_packets.to_variable_integer(12345)), 12345)
	
	local connect_packet = mqtt_packets.PacketConnect:new{}
	assert_equals(connect_packet:to_binary(), connect_packet:from_binary(connect_packet:to_binary()):to_binary())
	-- TODO: Do the same for the other packets.
end

local mqtt_client = loadfile("HUB:luiz.mqtt/scripts/mqtt_packet"){
	handle = handle,
	username = 'ezlo_test_username',
	password = '123456789',
	client_id = 'ezlo_test_client_id',
}

local function test_with_server()
	local packet = mqtt_client.connect()

	assert_equals(packet.type(), 'connack')
	assert_equals(packet.return_code, 0)
	mqtt_client.subscribe{
		topics = 'test/topic',
		packet_id = 7284,
	}
	mqtt_client.publish{
		topic = 'test/topic',
		message = 'Some test message',
	}
	local packet = mqtt_client.receive_packet()
	assert_equals(packet.type(), 'publish')
	assert_equals(packet.message, 'Some test message')
	assert_equals()

	-- TODO: Add tests for 'mqtt_packets' module.
end
