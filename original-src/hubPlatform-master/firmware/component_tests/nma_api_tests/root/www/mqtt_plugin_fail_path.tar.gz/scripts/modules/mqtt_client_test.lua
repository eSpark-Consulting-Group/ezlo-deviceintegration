local network = require('network')
local _logger = require('logging')

network.subscribe('HUB:luiz.mqtt/scripts/event_handler')

-- TODO: Implement acknowledgement.
-- TODO: Implement packet identifiers use.
-- TODO: Implement responses to error codes.
-- TODO: Implement persistent session.
-- TODO: Implement QOS 1 and 2.
-- TODO: Implement variable byte integers.
-- TODO: Add unit tests.

--------------------------------------
-- Generally useful funcions.

local function enumerate(iterator)
	return function (index)
		return (index or 0)+1, iterator()
	end
end

local function print_binary(raw_binary)
	for c in raw_binary:gmatch'.' do
		io.write(string.byte(c)..' ')
	end
	print()
end

local function get_binary_string(num, min_size)
	min_size = min_size or 1

	if num == true then
		num = 1
	elseif num == false then
		num = 0
	end

	local largest_power = 1
	while num >= largest_power do
		largest_power = largest_power * 2
	end
	largest_power = largest_power / 2

	local str = ''
	while largest_power >= 1 do
		if num >= largest_power then
			str = str..'1'
			num = num - largest_power
		else
			str = str..'0'
		end
		largest_power = largest_power / 2
	end

	while min_size > #str do
		str = '0'..str
	end

	return str
end

local function num_to_bytes(num, min_size)
	min_size = min_size or 0
	local binary = get_binary_string(num, min_size*8)

	-- Completing zeros to form a byte.
	binary = string.rep("0", (8-(#binary%8))%8)..binary

	local bytes = {}
	for i=1,#binary,8 do
		bytes[#bytes+1] = string.char(tonumber(string.sub(binary, i, i+7), 2))
	end

	return table.concat(bytes)
end

local function bytes_to_num(bytes)
	if #bytes > 8 then error("numbers can only be 8 bytes or less") end

	local num = 0
	
	for i=1,#bytes do
		num = num + (string.byte(bytes:sub(i,i)) << ((#bytes - i)*8))
	end

	return num
end

function from_variable_integer(bytes)
	local multiply = 1
	local value = 0

	for byte in bytes:gmatch'.' do
		byte = string.byte(byte)

		value = value + ((byte & 127) * multiply)
		multiply = multiply * 128
	end

	return value, nil
end

function to_variable_integer(num)
	local bytes = ''

	repeat
		local byte = num % 128

		num = num >> 7

		if num > 0 then
			byte = byte | 128
		end

		bytes = bytes..string.char(byte)
	until num == 0

	return bytes, nil
end


--------------------------------------
-- Packets

local DEFAULT_PROTOCOL_LEVEL = 4
local DEFAULT_KEEP_ALIVE = 30
local DEFAULT_TIMEOUT = 10

local MQTT_PACKET_TYPE = {
	[1] = 'connect',
	[2] = 'connack',
	[3] = 'publish',
	[4] = 'puback',
	[5] = 'pubrec',
	[6] = 'pubrel',
	[7] = 'pubcomp',
	[8] = 'subscribe',
	[9] = 'suback',
	[10] = 'unsubscribe',
	[11] = 'unsuback',
	[12] = 'pingreq',
	[13] = 'pingresp',
	[14] = 'disconnect',

	['connect'] = 1,
	['connack'] = 2,
	['publish'] = 3,
	['puback'] = 4,
	['pubrec'] = 5,
	['pubrel'] = 6,
	['pubcomp'] = 7,
	['subscribe'] = 8,
	['suback'] = 9,
	['unsubscribe'] = 10,
	['unsuback'] = 11,
	['pingreq'] = 12,
	['pingresp'] = 13,
	['disconnect'] = 14,
}

-- Returns the packet type according to its first byte.
function identify_packet(packet)
	-- NOTE: This syntax requires lua 5.3.
	return MQTT_PACKET_TYPE[string.byte(packet:sub(1,1)) >> 4]
end

local PacketConnect = {}
PacketConnect.__index = PacketConnect
function PacketConnect:new(args)
	local packet = {}

	-- Copying data.
	packet.flags = args.flags
	packet.protocol_level = args.protocol_level
	packet.keep_alive = args.keep_alive
	packet.will_topic = args.will_topic
	packet.will_message = args.will_message
	packet.user_name = args.user_name
	packet.password = args.password
	packet.client_id = args.client_id

	-- Setting defaults
	packet.flags = packet.flags or {}
	packet.client_id = packet.client_id or ''
	packet.protocol_level = packet.protocol_level or DEFAULT_PROTOCOL_LEVEL
	packet.keep_alive = packet.keep_alive or DEFAULT_KEEP_ALIVE

	-- Checking for bad data.
	if packet.flags.will and (not packet.will_topic or not packet.will_message) then
		error('will flag set without topic/message')
	end
	if #packet.client_id == 0 and packet.flags.clean_session == false then
		error('the cliend must have an id when \'Clean Session\' is true')
	end
	if packet.user_name then
		packet.flags.user_name = true
	end
	if packet.password then
		packet.flags.password = true
	end

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _', as some values may be `false`.
	if packet.flags.user_name == nil then
		packet.flags.user_name = false
	end
	if packet.flags.password == nil then
		packet.flags.password = false
	end
	if packet.flags.will_retain == nil then
		packet.flags.will_retain = false
	end
	if packet.flags.will_qos == nil then
		packet.flags.will_qos = 0
	end
	if packet.flags.will == nil then
		packet.flags.will = false
	end
	if packet.flags.clean_session == nil then
		packet.flags.clean_session = true
	end
	if packet.flags.reserved == nil then
		packet.flags.reserved = false
	end

  setmetatable(packet, PacketConnect)
  return packet
end

-- TEMP: Why.... why does this method exists? The client will never receive a CONNECT packet from the server... *facepalm*
function PacketConnect:from_binary(raw_bytes)
	local newPacketConnect = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	-- Retrieving packet type.
	local packet_type = identify_packet(byte)
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'connect' then
		error('packet type not CONNECT')
	end

	newPacketConnect.packet_type = packet_type
	
	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	newPacketConnect.remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))

	-- Retrieving protocol name.
	local msb, lsb
	index, msb = bytes_iter(index)
	index, lsb = bytes_iter(index)

	local len = bytes_to_num(msb..lsb)

	local protocol = ''
	for _=1,4 do
		index, byte = bytes_iter(index)
		protocol = protocol..byte
	end

	if len ~= 4 or protocol ~= 'MQTT' then error('not an MQTT procotol packet') end

	-- Retrieving protocol level.
	local protocol_level
	index, protocol_level = bytes_iter(index)
	if protocol_level ~= 4 then error('protocol level '..string.byte(protocol_level)..' not supported') end

	-- Retrieving connect flags.
	index, byte = bytes_iter(index)

	-- TODO: Finish this? (look at the 'TEMP' message above).
	--local flags = {
	--  user_name = 
	--  password = 
	--  will_retain = 
	--  will_qos = 
	--  will = 
	--  clean_session = 
	--  reserved = 
	--}

  setmetatable(newPacketConnect, self)
  return newPacketConnect
end

function PacketConnect:to_raw()
	-- NOTE: The binary packet is built in reverse order.

	local payload
	if self.flags.password then
		payload = num_to_bytes(#self.password, 2)..self.password..payload
	end
	if self.flags.user_name then
		payload = num_to_bytes(#self.user_name, 2)..self.user_name..payload
	end
	if self.flags.will then
		payload = num_to_bytes(#self.will_topic, 2)..self.will_topic..payload
		payload = num_to_bytes(#self.will_message, 2)..self.will_message..payload
	end
	payload = num_to_bytes(#self.client_id, 2)..self.client_id

	local flags = get_binary_string(self.flags.user_name)..get_binary_string(self.flags.password)..get_binary_string(self.flags.will_retain)..get_binary_string(self.flags.will_qos, 2)..get_binary_string(self.flags.will)..get_binary_string(self.flags.clean_session)..'0'
	flags = string.char(tonumber(flags, 2))

	local variable_header = string.char(0, 4)..'MQTT'..string.char(self.protocol_level)..flags..num_to_bytes(self.keep_alive, 2)

	local fixed_header = string.char(MQTT_PACKET_TYPE['connect'] << 4, #variable_header + #payload)

	local raw_packet = fixed_header..variable_header..payload

	return raw_packet
end

function PacketConnect:type()
	return 'connect'
end


local PacketConnack = {}
PacketConnack.__index = PacketConnack
function PacketConnack:from_binary(raw_bytes)
	local packet = {}
	local bytes_iter = enumerate(raw_bytes:gmatch('.'))
	local index, byte = bytes_iter()

	local packet_type = MQTT_PACKET_TYPE[string.byte(byte) >> 4]

	-- Retrieving packet type.
	if not packet_type then
		error('malformed MQTT packet')
	elseif packet_type ~= 'connack' then
		error('packet type not CONNACK')
	end

	packet.packet_type = packet_type
	
	-- Retrieving variable integer size.
	local start_index = index + 1
	local end_index = index + 1
	repeat
		index, byte = bytes_iter(index)
		end_index = index
	until (string.byte(byte) & 128) == 0

	local remaining_len = from_variable_integer(raw_bytes:sub(start_index, end_index))
	if remaining_len ~= 2 then
		error('invalid packet length for CONNACK')
	end

	-- Retrieving flags.
	packet.flags = {}

	local flags
	index, flags= bytes_iter(index)
	flags = string.byte(flags)

	packet.flags.session_present = (flags & 1 ~= 0)

	local return_code
	index, return_code= bytes_iter(index)
	
	packet.return_code = string.byte(return_code)

  setmetatable(packet, PacketConnack)
  return packet
end

function PacketConnack:to_binary()
	-- NOTE: The packet is built from back to front.
	local packet = ''

	-- Adding packet identifier.
	local msb = string.char(self.packet_identifier >> 8)
	local lsb = string.char(self.packet_identifier & 255)
	packet = msb..lsb..packet

	-- Adding remaining length.
	packet = to_variable_integer(#packet)..packet

	-- Adding first byte.
	packet = string.char(MQTT_PACKET_TYPE[self.packet_type] << 4)..packet
end

function PacketConnack:type()
	return 'connack'
end


local PacketPublish = {}
PacketPublish.__index = PacketPublish
function PacketPublish:new(args)
	local packet = {}

	-- Copying data.
	packet.flags = args.flags
	packet.qos = args.qos
	packet.topic = args.topic
	packet.packet_id = args.packet_id
	packet.payload = args.payload

	-- Setting defaults
	packet.flags = packet.flags or {}
	packet.qos = packet.qos or 0

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _' idiom, as some values may be `false`.
	if packet.flags.dup == nil then
		packet.flags.dup = false
	end
	if packet.flags.retain == nil then
		packet.flags.retain = false
	end

	-- Checking for bad data.
	if packet.topic == nil or #packet.topic == 0 then
		error('publish packet must have a (non-empty) topic')
	end
	if packet.qos < 0 or packet.qos > 2 then
		error('invalid QOS level '..packet.qos)
	end
	if packet.qos == 0 and packet.flags.dup then
		error('dup flag must be false for publish packets with QOS 0')
	end

  setmetatable(packet, PacketPublish)
  return packet
end

-- TEMP: Why.... why does this method exists? The client will never receive a CONNECT packet from the server... *facepalm*
function PacketPublish:from_binary(raw_bytes)
end

function PacketPublish:to_raw()
	-- NOTE: The binary packet is built in reverse order.

	local payload = self.payload


	local variable_header = num_to_bytes(#self.topic, 2)..self.topic
	if self.qos > 0 then
		variable_header = variable_header..self.packet_id
	end

	local flags = get_binary_string(self.flags.dup)..get_binary_string(self.qos, 2)..get_binary_string(self.flags.retain)
	flags = tonumber(flags, 2)

	local fixed_header = string.char((MQTT_PACKET_TYPE['publish'] << 4) + flags, #variable_header + #payload)

	local raw_packet = fixed_header..variable_header..payload

	return raw_packet
end

function PacketPublish:type()
	return 'publish'
end


local PacketSubscribe = {}
PacketSubscribe.__index = PacketSubscribe
function PacketSubscribe:new(args)
	local packet = {}

	-- Copying data.
	packet.qos = args.qos
	packet.topics = args.topics
	packet.packet_id = args.packet_id

	-- Setting defaults
	packet.qos = packet.qos or 2

	-- Checking for bad data.
	if not packet.topics then
		error('subscribe packet must have at least one topic')
	end
	if not packet.packet_id then
		error('subscribe packet must have a packet identifier')
	end

	-- Setting defaults
	-- NOTE: This cannot use the '_ = _ or _' idiom, as some values may be `false`.
	if packet.qos == nil then
		packet.qos = 2
	end

	-- Reformatting.
	if type(packet.topics) == 'string' then
		packet.topics = {packet.topics}
	end
	if type(packet.qos) == 'number' then
		local qos = packet.qos
		packet.qos = {}
		for i=1,#packet.topics do
			packet.qos[i] = qos
		end
	end

  setmetatable(packet, PacketSubscribe)
  return packet
end

-- TEMP: Why.... why does this method exists? The client will never receive a SUBSCRIBE packet from the server... *facepalm*
function PacketSubscribe:from_binary(raw_bytes)
end

function PacketSubscribe:to_raw()
	-- NOTE: The binary packet is built in reverse order.

	local payload = ''
	for i=1,#self.topics do
		payload = payload..num_to_bytes(#self.topics[i], 2)..self.topics[i]..string.char(self.qos[i])
	end

	local variable_header = num_to_bytes(self.packet_id, 2)

	local fixed_header = string.char((MQTT_PACKET_TYPE['subscribe'] << 4) + 2, #variable_header + #payload)

	return fixed_header..variable_header..payload
end

function PacketSubscribe:type()
	return 'subscribe'
end

--------------------------------------
-- MQTT functions.

local MqttClient = {}
MqttClient.__index = MqttClient
function MqttClient:new (args)
	-- These arguments must be passed.
	if args == nil then error("`args` table missing") end
	if args.address == nil then error("parameter missing `address`") end
	if args.port == nil then error("parameter missing `port`") end

	-- Default arguments.
	args.timeout = args.timeout or DEFAULT_TIMEOUT

	local newMqttClient =  {
		address = args.address,
		port = args.port,
		user_name = args.user_name,
		password = args.password,
		client_id = args.client_id,
		timeout = args.timeout,
		tcp_handle = nil, -- This becomes defined after a connection is stablished.
	}

  setmetatable(newMqttClient, self)
  return newMqttClient
end

function MqttClient:connect()
	local result, err

	result, err = network.connect{
		ip = self.address,
		port = self.port,
		connection_type = 'TCP',
	}
	if not result then error('connection failed') end

	self.tcp_handle = result

	local open_sockets = network.get_sockets()
	
	-- TODO: find out how to change timeout in the network API.
	--self.tcp_client:settimeout(self.timeout)

	local connect_packet = PacketConnect:new{
		user_name = self.user_name,
		password = self.password,
		client_id = self.client_id,
	}

	result = network.send(self.tcp_handle, connect_packet:to_raw())
	if not result then error('data not sent') end

	_logger.debug("some 2")

	result, err = self:receive_packet()
	if not result then error(err) end

	_logger.debug("some 3")

	local connack_binary = result

	if identify_packet(connack_binary) ~= 'connack' then
		error('message received upon connection to server is not connack')
	end

	return PacketConnack:from_binary(connack_binary)
end

function MqttClient:publish(args)
	local result, err

	local publish_packet = PacketPublish:new(args)

	result, err = network.send(self.tcp_handle, publish_packet:to_raw())
	if not result then error(err) end

	-- TODO: Once you start implement the highier QOS systems, change this to receive the acknowledgement.
	--result, err = self:receive_packet()
	--if not result then error(err) end
  --
	--local connack_binary = result
  --
	--if identify_packet(connack_binary) ~= 'connack' then
	--  error('message received upon connection to server is not connack')
	--end

	--return PacketConnack:from_binary(connack_binary)
	return nil
end

function MqttClient:subscribe(args)
	local result, err

	local subscribe_packet = PacketSubscribe:new(args)

	result, err = network.send(self.tcp_handle, subscribe_packet:to_raw())
	if not result then error(err) end

	return nil
end

function MqttClient:_receive_variable_integer()
	local bytes = ''

	repeat
		if #bytes > 4 then
			error('malformed remaining length')
		end

		local result, err = self.tcp_client:receive(1)

		if not result then
			return result, err
		end

		bytes = bytes..result
	until (string.byte(result) & 128) == 0

	return bytes, nil
end

function MqttClient:receive_packet()
	local result, err

	-- Receiving first byte.
	result, err = self.tcp_client:receive(1)
	if not result then return result, err end

	local first_byte = result

	if not identify_packet(first_byte) then
		error("malformed MQTT packet received")
	end

	-- Receiving variable integer.
	result, err = self:_receive_variable_integer()
	if not result then return result, err end

	local remaining_len = from_variable_integer(result)

	-- Receiving remaining of the packet.
	result, err = self.tcp_client:receive(remaining_len)
	if not result then return result, err end

	local remaining = result

	return first_byte..to_variable_integer(remaining_len)..remaining
end

-- TODO: Move this to a class.
local function make_packet_subscribe(args)
	assert(args.topics, 'subscription requires topics')
	args.max_qos = args.max_qos or 2
	args.id = args.id or 1

	if type(args.topics) == 'string' then
		args.topics = {args.topics}
	end

	local options = string.char(tonumber('000000'..get_binary_string(args.max_qos, 2), 2))
	
	local payload = ''
	for _,topic in ipairs(args.topics) do
		payload = payload..num_to_bytes(#topic, 2)..topic..options
	end

	local variable_header = num_to_bytes(args.id, 2)

	local fixed_header = string.char(130, #variable_header + #payload)

	local packet = fixed_header..variable_header..payload

	return packet
end

_logger.info("step 1")
local client = MqttClient:new{
	address = '127.0.0.1',
	port = 1883,
	client_id = 'test_id',
}

_logger.info("step 2")
local connack = client:connect()
print(connack.return_code)
client:publish{
	topic = 'testtopic/test',
	payload = 'abcd'
}

_logger.info("step 3")
client:subscribe{
	topics = 'a',
	packet_id = 10,
}

_logger.info("step 4")
local result, err = client:receive_packet()
if result then
	print(string.byte(result:sub(1,1)))
else
	print(err)
end




--print(client:connect('127.0.0.1', 1883))
--print(client:send(packet))

--packet = make_packet_publish{topic = 'test_topic/test_subtopic', payload = 'test'}
--print(client:send(packet))

--packet = make_packet_subscribe{topics = 'test_topic'}
--for c in packet:gmatch'.' do
--  io.write(string.byte(c), ' ')
--end
--print()
--print(client:send(packet))


