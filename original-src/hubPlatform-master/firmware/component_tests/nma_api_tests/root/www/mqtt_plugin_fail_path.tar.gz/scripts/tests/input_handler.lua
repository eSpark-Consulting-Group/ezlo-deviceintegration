local _logger = require('logging')
local _core = require('core')
local _network = require('network')

local params = ...

local activity_type = params.data.event.io_activity_type
local handle = params.data.event.handle
-- TODO: Remove this after adding address passing functionality.
local server_address = '127.0.0.1'


