local _logger = require('logging')
local _storage = require('storage')
local _core = require('core')

local params = ...

local activity_type = params.data.event.io_activity_type
local handle = params.data.event.handle

local _mqtt_client = loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_client"){ handle = handle }

if activity_type == "IN" then
	local packet = _mqtt_client.receive_packet()

	if packet:type() == 'publish' then
		-- TODO: Update the item value.
		_logger.info('PACKET RECEIVED: '..packet.topic..' ,'..packet.message)

		local items = _storage.get_table('items')

		_core.update_item_value(items.mqtt_message, packet.message)
		_core.update_item_value(items.mqtt_topic, packet.topic)
	end
end

