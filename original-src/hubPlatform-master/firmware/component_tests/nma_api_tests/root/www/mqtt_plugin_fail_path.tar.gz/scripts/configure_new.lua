local _network = require("network")
local _storage = require("storage")

-- TODO: How the hell do we pass the username and password to the connection handler? (maybe we don't and just create a 'make_connection' procedure instead of a 'connection_handler' procedure)
local function TryConnection (address, username, password, topic)
	_storage.set_table('connecting_params', {
		address = address,
		username = username,
		password = password,
		topic = topic,
	})

	_network.connect{
		ip = address,
		port = '1883',
		connection_type = 'TCP',
	}
end


-----------------------------------------------------------------------

local params = ... or {}

if params.devices and type(params.devices) == "table" then
    for _, mqtt_params in ipairs(params.devices) do
				TryConnection(params.address or '127.0.0.1', mqtt_params.username, mqtt_params.password, params.topic)
    end
else
		TryConnection(params.address or '127.0.0.1', params.username, params.password, params.topic)
end
