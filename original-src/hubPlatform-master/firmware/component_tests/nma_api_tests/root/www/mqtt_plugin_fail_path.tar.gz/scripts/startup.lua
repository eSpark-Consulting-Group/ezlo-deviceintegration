local _core = require("core")
local _logger = require("logging")
local _network = require("network")
local _storage = require("storage")

_logger.info("MQTT plugin starting...")

_logger.info("LOADED::"..tostring(loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_device")))
_logger.info("LOADED::"..tostring(loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_packets")))

_storage.set_table('active_connections', {})
_network.subscribe('HUB:luiz.mqtt/scripts/connection_handler')

_logger.info("MQTT plugin started")
