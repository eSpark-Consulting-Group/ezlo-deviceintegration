local _logger = require("logging")

local SETTING_NAME = "set_username"

local function CreateOrUpdateSetting(device_id, setting_id, value)

    if setting_id then
        local _core = require("core")
        _core.set_setting_value(setting_id, value, "synced")
        return
    end

    local _setting_utils = require("HUB:luiz.mqtt/scripts/modules/setting_utils")

    local setting = {
        label = {
            text = "Username"
        },
        description = {
            text = "Username of MQTT client."
        },
        value_type = "string",
        value = value,
        status = "synced",
        has_setter = true,
        info = {
            name = SETTING_NAME
        }
    }

    _setting_utils.CreateSetting(device_id, SETTING_NAME, setting)

end

local params = ... or {}

if not params.device_id then
    _logger.error("Missing device_id. Cannot continue.")

    return
end

CreateOrUpdateSetting(params.device_id, params.setting_id, params.value)
