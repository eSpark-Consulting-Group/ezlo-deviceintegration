local _core = require("core")
local _logger = require("logging")


local params = ... or {}

_logger.info(params)

local item = _core.get_item(params.item_id)
_logger.info(item)
local device_id = item.device_id
local value = params.value

loadfile("HUB:luiz.mqtt/scripts/items/mqtt_packet_publish"){
	value = value,
	device_id = device_id,
}
