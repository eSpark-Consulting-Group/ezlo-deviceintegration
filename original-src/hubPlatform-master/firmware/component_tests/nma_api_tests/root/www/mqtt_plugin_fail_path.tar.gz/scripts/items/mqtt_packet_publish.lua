local _storage = require('storage')
local _logger = require('logging')


local params = ...
local value = params.value
local device_id = params.device_id
local handle = _storage.get_table('handle_from_device_id')[device_id]
_logger.info("THISS: "..device_id..tostring(handle))


if not handle then
	error('No connection handler found for MQTT device.')
elseif not value.Topic then
	error('No topic found')
end

if not value.Message then
	value.Message = ''
end

_logger.info("SENDING PACKET TO"..value.Topic)

local _mqtt_client = loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_client"){ handle = handle }

_mqtt_client.publish({
	topic = value.Topic,
	message = value.Message,
	qos = tonumber(value.QoS),
})
