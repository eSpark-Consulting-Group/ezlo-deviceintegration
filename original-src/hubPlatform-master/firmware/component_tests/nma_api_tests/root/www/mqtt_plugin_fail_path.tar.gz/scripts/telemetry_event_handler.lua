local _logger = require('logging')
local _core = require('core')
local _storage = require('storage')
local json = require('HUB:luiz.mqtt/scripts/modules/json')

local TELEMETRY_PREFIX = 'ezlo_mqtt/telemetry'

local params = ... 

local function encode(value)
 	if value == nil then
		return ''
	elseif type(value) == 'table' then
		return json.encode(value)
	else
		return tostring(value)
	end
end

local event = params.event

local topic
local message

if event == 'device_added' then
 	topic = TELEMETRY_PREFIX..'/device/added/'..params._id
	message = ''

elseif event == 'device_removed' then
 	topic = TELEMETRY_PREFIX..'/device/removed/'..params._id
	message = ''

elseif event == 'device_updated' then
	-- Deciding which value has changed.
	local changed_param = nil
	for _,val in ipairs{'name', 'reachable', 'roomId', 'ready'} do
		if params[val] ~= nil then
			changed_param = val
			break
		end
	end

 	topic = TELEMETRY_PREFIX..'/device/updated/'..params._id..'/'..changed_param
	message = encode(params[changed_param])

elseif event == 'device_setting_added' then
 	topic = TELEMETRY_PREFIX..'/device_setting/added/'..params._id
 	message = encode(params.value)

elseif event == 'item_added' then
 	topic = TELEMETRY_PREFIX..'/item/added/'..params._id
 	message = encode(params.value)

elseif event == 'item_removed' then
 	topic = TELEMETRY_PREFIX..'/item/removed/'..params._id
	message = ''

elseif event == 'item_updated' then
	-- Deciding which value has changed.
	local changed_param = nil
	for _,val in ipairs{'show', 'valueFormatted', 'value', 'valueMin', 'valueMax'} do
		if params[val] ~= nil then
			changed_param = val
			break
		end
	end

 	topic = TELEMETRY_PREFIX..'/item/updated/'..params._id..'/'..changed_param
 	message = encode(params[changed_param])

elseif event == 'gateway_setting_added' then
 	topic = TELEMETRY_PREFIX..'/gateway_setting/added/'..params.id
 	message = encode(params.value)

elseif event == 'gateway_setting_removed' then
 	topic = TELEMETRY_PREFIX..'/gateway_setting/removed/'..params.id
	message = ''

elseif event == 'gateway_setting_updated' then
 	topic = TELEMETRY_PREFIX..'/gateway_setting/updated/'..params.id
 	message = encode(params.value)

-- TODO: Implement 'item_dictionary_updated'.
elseif event == 'item_dictionary_updated' then
	if params.operation == 'added' then
		topic = TELEMETRY_PREFIX..'/item_dictionary/added/'..params._id
		message = ''
	elseif params.operation == 'removed' then
		topic = TELEMETRY_PREFIX..'/item_dictionary/remove/'..params._id
		message = ''
	elseif params.operation == 'updated' then
		topic = TELEMETRY_PREFIX..'/item_dictionary/updated/'..params._id
		message = encode(params.value)
	else
		_logger.error('item dictionary operation ('..params.operation..') not recognized')
	end
else
	return
end

-- Sending message.
for handle,_ in pairs(_storage.get_table('active_connections')) do
	local mqtt_client = loadfile("HUB:luiz.mqtt/scripts/modules/mqtt_client") { handle = handle }

	mqtt_client.publish({
		topic = topic,
		message = message,
	})
end


--_logger.debug(params)
