local _core = require("core")
local _logger = require("logging")
local _storage = require("storage")

_logger.info("MQTT plugin teardown...")

-- Freeing up storage.
_storage.delete_all()

-- TODO: Gracefully disconnect from servers.

_logger.info("Teardown complete")
