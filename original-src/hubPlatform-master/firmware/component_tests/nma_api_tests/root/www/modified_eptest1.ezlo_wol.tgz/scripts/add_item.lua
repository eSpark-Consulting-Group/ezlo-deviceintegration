local _core = require("core")
local _logger = require("logging")

local ITEM_NAME = "wol_packet_send"

local params = ... or {}

if not params.device_id then
    _logger.error("Missing device_id. Cannot create item")
    return
end

local item = {
    name = ITEM_NAME,
    value_type = "bool",
    value = false,
    has_getter = false,
    has_setter = true,
    device_id = params.device_id
}

local item_id = _core.add_item(item)

if item_id then
    _logger.info("Created item ID: " .. item_id)
else
    _logger.error("Failed to create item")
end
