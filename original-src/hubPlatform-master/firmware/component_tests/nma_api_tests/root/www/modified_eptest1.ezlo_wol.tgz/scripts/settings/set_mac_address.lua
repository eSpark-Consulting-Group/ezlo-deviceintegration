local _logger = require("logging")

local SETTING_NAME = "set_mac_address"

local function CreateOrUpdateSetting(device_id, setting_id, value)

    if not value or value == "" then
        _logger.error("Device mac address is empty")
        return
    end

    local parsed_mac = string.gsub(value, '[:-]', '')

    if #parsed_mac ~= 12 then
        _logger.error("Invalid mac address")
        return
    end

    if setting_id then
        local _core = require("core")
        _logger.debug("Update setting value: " .. SETTING_NAME .. " = " .. tostring(parsed_mac))
        _core.set_setting_value(setting_id, parsed_mac, "synced")
        return
    end

    local _setting_utils = require("HUB:eptest1.ezlo_wol/scripts/modules/setting_utils")

    local setting = {
        label = {
            text = "MAC address"
        },
        description = {
            text = "e.g. 001122AABBFF or 00:11:22:AA:BB:FF"
        },
        value_type = "string",
        value = parsed_mac,
        status = "synced",
        has_setter = true,
        info = {
            name = SETTING_NAME
        }
    }

    _setting_utils.CreateSetting(device_id, SETTING_NAME, setting)

end

local params = ... or {}

if not params.device_id then
    _logger.error("Missing device_id. Cannot continue.")

    return
end

CreateOrUpdateSetting(params.device_id, params.setting_id, params.value)
