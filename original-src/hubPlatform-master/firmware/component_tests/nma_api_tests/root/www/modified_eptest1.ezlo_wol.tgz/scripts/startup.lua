local _logger = require("logging")

_logger.info("Wake on LAN plugin starting...")
