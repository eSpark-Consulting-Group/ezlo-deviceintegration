local _logger = require("logging")

local SETTING_NAME = "set_port"

local function CreateOrUpdateSetting(device_id, setting_id, value)

    value = value or 9

    if value > 65535 then
        _logger.error("Invalid port : " .. tostring(value))
        return
    end

    if setting_id then
        local _core = require("core")
        _logger.debug("Update setting value: " .. SETTING_NAME .. " = " .. tostring(value))
        _core.set_setting_value(setting_id, value, "synced")
        return
    end

    local _setting_utils = require("HUB:eptest1.ezlo_wol/scripts/modules/setting_utils")

    local setting = {
        label = {
            text = "Port"
        },
        description = {
            text = "e.g. 7 or 9"
        },
        value_type = "int",
        value = value,
        status = "synced",
        has_setter = true,
        info = {
            name = SETTING_NAME
        }
    }

    _setting_utils.CreateSetting(device_id, SETTING_NAME, setting)

end

local params = ... or {}

if not params.device_id then
    _logger.error("Missing device_id. Cannot continue.")

    return
end

CreateOrUpdateSetting(params.device_id, params.setting_id, params.value)
