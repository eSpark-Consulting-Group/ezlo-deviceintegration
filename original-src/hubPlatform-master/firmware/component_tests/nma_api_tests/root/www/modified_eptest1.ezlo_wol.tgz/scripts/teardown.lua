local _logger = require("logging")
local _core = require("core")
local _storage = require("storage")


_logger.info("Wake on LAN plugin teardown...")

_logger.info("Remove all devices")
_core.remove_gateway_devices((_core.get_gateway() or {}).id)

_logger.info("Clear all storage")
_storage.delete_all()

_logger.info("Teardown complete")
