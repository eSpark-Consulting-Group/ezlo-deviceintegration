local _core = require("core")
local _logger = require("logging")
local _network = require("network")

local params = ... or {}

local items = {}

if type(params.item_id) == "string" then
    items[params.item_id] = { value = params.value }

elseif type(params.item_ids) == "table" then
    for _, item_id in ipairs(params.item_ids) do
        items[item_id] = { value = params.value }
    end

elseif type(params.items) == "table" then
    items = params.items
end

for item_id, _ in pairs(items) do
    local item = _core.get_item(item_id)
    local setting_ids = _core.get_setting_ids_by_device_id( item.device_id )
    local sync_str = "FFFFFFFFFFFF"
    local mac = ""
    local port = 9
    local password = ""

    if setting_ids then
        for _, setting_id in pairs(setting_ids) do
            local  setting = _core.get_setting(setting_id)

            if setting.info.name == "set_mac_address" then
                mac = setting.value
            elseif setting.info.name == "set_port" then
                port = setting.value
            elseif setting.info.name == "set_password" then
                password = setting.value
            end
        end
    end

    local data = ""

    for i = 1, #sync_str, 2 do
        local char = tonumber(string.sub(sync_str, i, i + 1), 16)
        data = data .. string.char(char)
    end
    
    local bin_mac = ""
    for i = 1, #mac, 2 do
        local char = tonumber(string.sub(mac, i, i + 1), 16)
        bin_mac = bin_mac .. string.char(char)
    end
    
    for i = 1, 16 do
        data = data .. bin_mac
    end

    local bin_password = ""
    for i = 1, #password, 2 do
        local char = tonumber(string.sub(password, i, i + 1), 16)
        bin_password = bin_password .. string.char(char)
    end

    data = data .. bin_password

    local handle = _network.udp()
    _network.setoption(handle, "broadcast")

    local success, errmsg = pcall(_network.sendto, handle, data, "255.255.255.255", port)

    if not success then
        _logger.error("Failed to send data, error: " .. errmsg)
    end

    _network.close(handle)

end
