local _core = require("core")
local _logger = require("logging")

local function CreateDevice ( device_name, device_mac, device_port, device_password )

    if not device_name or device_name == "" then
        _logger.error("Device name is empty")
        _core.send_ui_broadcast({
            status = "error",
            message = "Device name is empty."
        })
        return
    end

    if not device_mac or device_mac == "" then
        _logger.error("Device mac address is empty")
        _core.send_ui_broadcast({
            status = "error",
            message = "Device mac address is empty."
        })
        return
    end

    local parsed_mac = string.gsub(device_mac, '[:-]', '')

    if #parsed_mac ~= 12 then
        _logger.error("Invalid mac address")
        _core.send_ui_broadcast({
            status = "error",
            message = "Invalid mac address."
        })
        return
    end

    device_port = device_port or 9
    device_password = device_password or ""

    if type(device_port) ~= "number" or device_port > 65535 then
        _logger.error("Invalid port")
        _core.send_ui_broadcast({
            status = "error",
            message = "Invalid port."
        })
        return
    end

    if #device_password & 1 == 1 then
        _logger.error("Invalid password")
        _core.send_ui_broadcast({
            status = "error",
            message = "Invalid password."
        })
        return
    end

    local device_id = _core.add_device({
        type = "device",
        device_type_id = "wol",
        category = "remote_control",
        battery_powered = false,
        gateway_id = _core.get_gateway().id,
        name = device_name
    })

    if not device_id then
        _logger.error("Failed to create device")
        _core.send_ui_broadcast({
            status = "error",
            message = "Device is not added. Cannot continue."
        })
        return
    end

    _logger.info("Created device with ID: " .. device_id)
    _core.send_ui_broadcast({
        status = "success",
        message = "Device added successfully."
    })

    loadfile("HUB:eptest1.ezlo_wol/scripts/add_item") { device_id = device_id }

    loadfile("HUB:eptest1.ezlo_wol/scripts/settings/set_port") { device_id = device_id, value = device_port }
    loadfile("HUB:eptest1.ezlo_wol/scripts/settings/set_mac_address") { device_id = device_id, value = parsed_mac }
    loadfile("HUB:eptest1.ezlo_wol/scripts/settings/set_password") { device_id = device_id, value = device_password }

end

-----------------------------------------------------------------------

local params = ... or {}

if params.devices and type(params.devices) == "table" then
    for _, wol_params in ipairs(params.devices) do
        CreateDevice(wol_params.name, wol_params.mac, wol_params.port, wol_params.password)
    end
else
    CreateDevice(params.name, params.mac, params.port, params.password)
end
