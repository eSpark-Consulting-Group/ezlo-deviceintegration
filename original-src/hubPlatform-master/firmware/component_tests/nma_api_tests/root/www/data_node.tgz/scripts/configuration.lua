print( "TEST_PLUGIN: Configuration" )
